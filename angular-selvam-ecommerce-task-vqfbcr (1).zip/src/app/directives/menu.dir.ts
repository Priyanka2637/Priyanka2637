import { Component } from '@angular/core';

@Component({
  selector : 'menu',
  template : `
  <nav class="navbar navbar-expand-lg navbar-light bg-light d-print-none">
  <a class="navbar-brand" href="#" routerLink = '/products'><img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAARMAAAC3CAMAAAAGjUrGAAAAyVBMVEX////qIifqHyTqGB/rLjPpAADpAAvpAAbpBBD94+S5wcP3trf6y8z70tPpFBrqHCG7vL7sODzvYWTpDBTrKS64xMb729z/+fnxe331o6XuTE/vZWn/+vr5xcbyhYfsPEDuVlnzkJL0l5m/r7H5x8j96uq8tbf4vL3tSUzPg4bfT1LIl5nsQUX2rK7uUVT+8PD0nqDbXmHXam3wbnHCp6nGnZ/SfH/TdXjzi43hRknhOT7qqKrW1Nbq5+jWbW/ZYmXdV1vNjI/X4OEeZEjNAAAKHElEQVR4nO2da3PaOhOAdUG2MCBDBMaEOwRMCNeQNJfztknO//9RZ1fGSd56mnY60+nE7PMhsbCcGT8jrVayTBgjCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgCIIgiGLT+6R/+0/SLP05mn/75n4TE4o/RWj+9s39JlLwP4WQf/vmfhNykoec5CEnechJHnKSh5zkISd5yEkecpKHnOQhJ3nISR5ykoec5CEnechJnl92IqBiaKwx1obkBO7O+iYURj9c3kynNy/LX7NSaCfWjKMeY7ObIKjXgyBo3TzYE3eiYhASxfs6ENRvbm/mrdb1L0gpsBN/DdUG6gHbyPSaW+3Zx5fWkzlhJ94Oao08PgUll8YIYc1oMP4nePTlqTqRI6gUa/MlqAd3Gspmt3UX/q+68U7UiV9jrKa4nNaDK3BgzmfHC78ytlMn6cQMv/ZYV4aP0ExKgptNetW27X6tP5RSUCd2HzDWDoXcB8GV5qIELtqdc6UUjyO4+v6j4aeYTuy3oMJY2efyKQiuJfcSxi6EhxmbMGoAl5c+uLyQTuSy9aUDTiCc7IPWMhQNxioKLhBhGAquR4x1PmgoxXQyDTiMxGWPhw9B6yE0Yxb5gkvbWD4vG8bomM3803Ii962pOkCdpuDhvLWX0HU2MjTXN5jgBzffpKqxxo+vL6ITewVxtQR5/cBwc9m6tCqqKfM4bbVQCWa1j122+fF0sIhOzDR4sR4E2ZniojmfGxVN/GWrfvXteX9366wsT80JnwdXNmzA8NuBKPvc+qYuDqX6JUyTpTR6eAVS5rMT6zt8Xp9rbmOoNVbCPgXDyeHqWXmeNri+pO9QyomNO5jPP4TcQylJ0/cfbvf3T3FSvagMSh5cpnEO9HxafQdibHALcxy7wJQ1ic9X9//cH+IdlircgBQYgF5+3FCK6ASS13qAi0eh2nRq21lttx8/XXFfbcBKe2QxxtSnP15HKaITbuYwtOw11JAWpjjq8bZ7vwyWRipcZhoZbiHi/PjyIjoRpa+42njZtBJyeWOug8dDX32BhJYrmPhsudC3wYk5Cc971y2QMn/ZPzw+f5m2ntQ4UmF9KmAGuGVsre1LMP3xalshnSzY6KmeLtUHQav+bFU1UvaldQe9ZgINRUAUvj2tGAvT4AvVeHFKWvPLpgyHrO/JpxbEVVGCa7vqpnV9Wu2Ee1s2sjZcXt9dLyXkaarPJjZ8aAWPgusZYxMZzE9t/USvWbtheCiNhMxMKOgvizBctoK95KoMKf83mCyfmJNwBUFjpNxtC+N1GLtIl9yeJPfBSaX+5fTWHlEDS0bW8zwegwS2CjmMNdBOhISpYXD34dPAYjrhfhXrbGu1yC3UHywXvI6zIDlivX+XHz8gLagTYZN3r7AdNMSYl6A+d+GWRSf6zEv4h/K/ac1K07iHG+4R6Rl8cPjJI+OiOoFJj1oGyboTc0/wUF9DClcvWVxoSj5Yni64E2gbd/VvobLGmodbzGr36gwy+6r92ZVFdsL1Zat+83J5NcU12PrTBmIJW3s/vbDQTrh9mrfSpfqg/hW6zTZZ/CS+Ft8Jl+L6dl6vz6+ewsZoNDTer2xoK7gTXFXC7ThWChH+6iWFd/IbkBNyQk7ICTkhJznISR5ykoec5CEnechJHnKSh5zkee9E+P7rSpEw2kfc0rzUnivgSWHTY1yMPdZJL8tO+L4ujpNwFdVqx83iMhwkNaSiQdXZuuoKDcFtY9LHw+jeCHus487IUnoCSExhnOC2TzZxDcOMtsfzkRKmmlVehd4gO15rW3v7M0NZar8WZrooTgTH8hb3NApcl+9VkbX2cfk1coWG6WIVPKwNPNxiXaumNFBo71ioFKadaNxaz1hs3MNzVtXKxRN80au3UWnU8PDJuXIFg5UGKosn+Ex9qAoWT3Dr0bbk3kzhFnpOeFxyxVsfH1ekw3PsTLiTKwyFhpaxse4QTqkZ23p4Rrw1vE/vxAzwvS3oJ2dSDN37bin48lv2lo6Joc7q3NHArUrVDRytSlq6ap0FlIY8G7s+vxMNjb+BzzxrKtwwVtFZ5I0Yyx5cmPHbhR1vlR32oo00r8G3nTRFMZwYiJhVJRUYWJnvnPQyJ/adk7W1cTY44R5Ity8jpVqQcQfb/qR7OIPokagh+nnXd/j7vjM6c6wEN2aFR4eZi8xanGPpvpf1tc/uRG7efdaEGNvLHge74eXYaLBT1ZR0uNMhHuGgvLP4RhyWFITekSyCE3z78ZUObglOlKcBIyEl2TYUHmuBO/sG6bHkQqeoe0z1ZFa6YMeXej65E3z7sT1EGhvM2zB8zirIxHrQeXp9V2hYjKQRHiaxWSXuwwrq7NrDsYTJLS9C38EOsvbdNyarKr6uc8g2J0Fu34yyypDb77LjtT96+ys1iyNzxs4WIcaaqFxepEmaPJuVL4xt7KplJPFgwhv3I1cYCq436xoezsZ6MyunVCdCmMGxFPUPthj5ifVetwpIz7Nu5u9Ip4TpMb6hgesGDgPDbwbGY/layrZ0fXYnBkEroZGvPwV8Jv/vrDj+Pp54rcClxT0H0pXk8bNP7kTGwGGleTiKuxLG3AH8FEP8EO6vmZ0VDTg4D7mAX1gBiwd0ZM8mu/Gh2Y27hstRHBdhLFZpSE0sBNuaz+0OYitPwyYXOCi5sxrHZVbxcCr4VgEyeZuO5BMYlZohzCXXtghO2qy/TnDA6TgnE5wD+hesv8UpIThZr2E4GnjoZOZZSEhchX5aAVVdjDuVripDbjNgbVGEsRicdBVkoFV0oo5OIJtd4JsY4KRtPRij+6rLthErQUp34Zxs2SaBkVd3WFlZqyVMmtrgZVeI+Q44OUhnogNejMIjfANBT1jVRyciVGs4A046LFazHlbAJQUPK0ASXEmniTCFvGBbUYh5cdpOsCVks9uagtl/pEaQ1IbgZNU4a7Od32XtEVs3WHWMFWJoHlBBe1W2TpuGCziTYuQn4KTWLzN2ACe92WwGRaUrbK28HlvIY4ydCQNOFItiNsZ2AvF4rWybLdSrE65qbCuLsaak3KL7dqztW9/xyixKkjaLLTi56PdYF+eDbVXr9dkKK/gRVKi0YVKYsOS4xAIjVjXbc/75ncTDlbDcvsXY7L/nVHzoOxraQuI7J/h2pNphteOcqKIwxnoav7ANnXqFcXKwuNZs38ZiiKeQkeHtghP3VQ7S9Z0Rg7CDFc5Y+4AVZvhRtK5UIb8rkhMIJS73tG85G7YYY2HwKTUwFeO4fA8h1A+rUQwnswoLOHmcLe/SdlYQJ+Fi0Uzvo7GAyS/8XMnhAr/bRCzOm3yxwCeni5VoLhaC+8p8X0E3BvfxRmTXF8IJz57mcOGe1uDP9MidcWddOav3XYXXyWH2YRGc/AnICTkhJ+SEnJCTHPR/JPPQ/xvNQ/+XliAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiAIgiB+n/8AD8PkVjlXY8gAAAAASUVORK5CYII=" class="logo mr-2"/>Online Medicine<br>HOSPITO</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarNav">
    <ul class="navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" routerLink = '/products'>Products <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" routerLink = '/billing'>Billing</a>
      </li>
      <li class="nav-item">
        <a class="nav-link"  routerLink = '/checkout'>Checkout</a>
      </li>      
    </ul>
  </div>
</nav>
  `,

  styles:[`
    .logo{
      height: 60px;
      width: auto;
    }
  `]
})

export class MenuDir{

}