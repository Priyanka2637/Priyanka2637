import { Injectable } from '@angular/core';

@Injectable()
export class CompanyDetailsModel{
  
  public companyInfo : any = 
    {
      name : 'Online Medicine',
      address : 'Anandpur',
      city: 'Kolkata',
      pincode: '700107',
      email: 'customer.care@p2s2shoppee.com',
      phone : '110-2353278'
    }
    
  
} 